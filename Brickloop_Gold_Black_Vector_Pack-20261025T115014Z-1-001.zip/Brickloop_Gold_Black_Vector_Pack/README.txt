BRICKLOOP - GOLD & BLACK VECTOR SYSTEM
Caption: Not Every Property Deserves Your YES

SVG/: editable vector masters; lettering and ribbon are outlined paths.
PDF/: vector exports matching each SVG (RGB; not press-profiled PDF/X).
PNG/: 2400px-wide previews, including transparent-background variants.
Favicon/: pixel-size PNGs and SVGs at 16, 32 and 64px, plus favicon.ico.
Guidelines/: five-page vector production guide.

MODES
two_color: flat black BRICK, gold brick accents and LOOP; transparent canvas.
gold_on_black: flat gold logo and black background.
metallic_gold: gold vector gradient on black; digital use.
black: pure solid black on transparent canvas.
white: pure solid white on transparent canvas.
white_on_black: white on black background.

The black monochrome SVG/PDF uses pure #000000. The presentation black is #0B0B0B.
Clear-space padding is 1 B height on every side; use artwork width for minimum sizing.
The B icon has a simplified 16px design. Do not shrink the full logo to favicon size.
No navy, steel blue or silver/chrome has been retained.
Gold is a colour simulation unless a printer assigns a real metallic ink or foil.
Geometric redraw based on the supplied Brickloop_Logo(6).JPG; not an automatic trace.

CALIBRATION
Wordmark cap height: 100 units. Canvas padding: 102 units.
Horizontal glyph origins: B 0; R 114; I 220; C 260; K 375; L 483; OO 567; P 812.
Tagline: outlined DejaVu Sans, 22 units, tracking +1.25 units, baseline 160.
Stacked tagline: 17 units, tracking +0.36 units, baseline 284.
Stacked LOOP origin: x25 / y139.
Taglines are centred using advance widths with fixed optical spacing.
